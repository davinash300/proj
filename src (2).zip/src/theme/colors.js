const colors = {
    primary: "rgb(28,37,63)",   // MUI default blue
    secondary: "#ff9800", // MUI default orange
    background: "rgb(28,37,63)",
    text: {
      primary: "#212121",
      secondary: "#757575",
    },
  };
  
  export default colors;
  